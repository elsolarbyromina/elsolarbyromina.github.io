:root {
    --primary: #6c5ce7; /* Violeta moderno */
    --secondary: #a29bfe;
    --dark: #2d3436;
    --light: #dfe6e9;
    --glass: rgba(255, 255, 255, 0.7);
    --glass-border: rgba(255, 255, 255, 0.5);
    --shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
}

* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }

body {
    background: linear-gradient(120deg, #fdfbfb 0%, #ebedee 100%);
    color: var(--dark);
    overflow-x: hidden;
}

/* --- HEADER & NAV --- */
header {
    position: sticky;
    top: 0;
    z-index: 100;
    background: rgba(255, 255, 255, 0.8);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border-bottom: 1px solid var(--glass-border);
    padding: 1rem 5%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}

.logo { font-weight: 700; font-size: 1.5rem; color: var(--primary); letter-spacing: -1px; }

.cart-btn {
    position: relative;
    background: var(--dark);
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 50px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: transform 0.2s;
}
.cart-btn:hover { transform: scale(1.05); }
.cart-count { font-size: 0.8rem; background: var(--primary); padding: 2px 6px; border-radius: 10px; }

/* --- HERO SECTION --- */
.hero {
    text-align: center;
    padding: 5rem 1rem;
    background: radial-gradient(circle at 50% 50%, rgba(108, 92, 231, 0.1) 0%, transparent 50%);
}
.hero h1 { font-size: 3rem; margin-bottom: 1rem; background: -webkit-linear-gradient(45deg, var(--primary), #0984e3); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.hero p { font-size: 1.1rem; color: #636e72; max-width: 600px; margin: 0 auto 2rem auto; }

/* --- FILTROS --- */
.filters { display: flex; justify-content: center; gap: 1rem; margin-bottom: 3rem; flex-wrap: wrap; }
.filter-btn {
    padding: 0.6rem 1.5rem;
    border: none;
    background: white;
    border-radius: 30px;
    cursor: pointer;
    font-weight: 600;
    box-shadow: 0 4px 6px rgba(0,0,0,0.05);
    transition: 0.3s;
}
.filter-btn.active, .filter-btn:hover { background: var(--primary); color: white; transform: translateY(-2px); box-shadow: 0 8px 15px rgba(108, 92, 231, 0.3); }

/* --- GRID PRODUCTOS --- */
.container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
.products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 2rem;
    padding-bottom: 5rem;
}

.card {
    background: rgba(255, 255, 255, 0.6);
    border-radius: 20px;
    border: 1px solid white;
    overflow: hidden;
    backdrop-filter: blur(5px);
    box-shadow: var(--shadow);
    transition: 0.4s ease;
    position: relative;
}
.card:hover { transform: translateY(-10px); box-shadow: 0 15px 40px rgba(0,0,0,0.1); }

.card-img {
    height: 250px;
    width: 100%;
    background-color: #ddd;
    overflow: hidden;
}
.card-img img { width: 100%; height: 100%; object-fit: cover; transition: 0.5s; }
.card:hover .card-img img { transform: scale(1.1); }

.card-info { padding: 1.5rem; }
.card-cat { font-size: 0.8rem; color: var(--primary); font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }
.card-title { font-size: 1.2rem; margin: 0.5rem 0; font-weight: 600; }
.card-price { font-size: 1.3rem; font-weight: 700; color: var(--dark); }

.add-btn {
    width: 100%;
    padding: 10px;
    margin-top: 1rem;
    border: none;
    background: var(--dark);
    color: white;
    border-radius: 10px;
    cursor: pointer;
    transition: 0.3s;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 5px;
}
.add-btn:hover { background: var(--primary); }

/* --- INFO PAGO / ENVIO --- */
.info-section {
    background: var(--dark);
    color: white;
    padding: 4rem 1rem;
    margin-top: 2rem;
}
.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    max-width: 1000px;
    margin: 0 auto;
    text-align: center;
}
.info-item i { font-size: 2.5rem; margin-bottom: 1rem; color: var(--secondary); }
.info-item h3 { margin-bottom: 0.5rem; }
.info-item p { font-size: 0.9rem; opacity: 0.8; }

/* --- FOOTER --- */
footer { text-align: center; padding: 2rem; font-size: 0.9rem; color: #888; }

/* --- CARRITO SIDEBAR --- */
.sidebar {
    position: fixed;
    top: 0;
    right: -400px;
    width: 350px;
    height: 100vh;
    background: white;
    box-shadow: -5px 0 30px rgba(0,0,0,0.2);
    z-index: 200;
    transition: 0.4s cubic-bezier(0.77, 0, 0.175, 1);
    display: flex;
    flex-direction: column;
    padding: 2rem;
}
.sidebar.open { right: 0; }

.cart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; border-bottom: 1px solid #eee; padding-bottom: 1rem; }
.close-cart { font-size: 1.5rem; cursor: pointer; background: none; border: none; }

.cart-items { flex: 1; overflow-y: auto; }
.cart-item { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 1px solid #f1f1f1; }
.item-details h4 { font-size: 0.9rem; }
.item-price { font-size: 0.85rem; color: #888; }
.remove-item { color: #ff7675; cursor: pointer; background: none; border: none; font-size: 1.2rem; }

.cart-footer { margin-top: auto; border-top: 1px solid #eee; padding-top: 1rem; }
.total-row { display: flex; justify-content: space-between; font-weight: 700; font-size: 1.2rem; margin-bottom: 1rem; }

.whatsapp-btn {
    width: 100%;
    padding: 1rem;
    background: #25D366;
    color: white;
    border: none;
    border-radius: 12px;
    font-weight: 600;
    font-size: 1rem;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    transition: 0.3s;
}
.whatsapp-btn:hover { background: #1ebd59; box-shadow: 0 5px 15px rgba(37, 211, 102, 0.3); }

/* Overlay fondo oscuro */
.overlay {
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.4);
    backdrop-filter: blur(3px);
    z-index: 150;
    opacity: 0; pointer-events: none; transition: 0.3s;
}
.overlay.active { opacity: 1; pointer-events: all; }

/* Responsive */
@media (max-width: 600px) {
    .sidebar { width: 100%; right: -100%; }
    .hero h1 { font-size: 2rem; }
}